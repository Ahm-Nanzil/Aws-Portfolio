google.maps.__gjsload__("overlay", function (_) {
  var $ya = function () {},
    BI = function (a) {
      a.MB = a.MB || new $ya();
      return a.MB;
    },
    aza = function (a) {
      this.Dg = new _.Mq(() => {
        const b = a.MB;
        if (a.getPanes()) {
          if (a.getProjection()) {
            if (!b.Fg && a.onAdd) a.onAdd();
            b.Fg = !0;
            a.draw();
          }
        } else {
          if (b.Fg)
            if (a.onRemove) a.onRemove();
            else a.remove();
          b.Fg = !1;
        }
      }, 0);
    },
    cza = function (a, b) {
      const c = BI(a);
      let d = c.Eg;
      d || (d = c.Eg = new aza(a));
      _.Mb(c.Dg || [], _.xn);
      var e = (c.Gg = c.Gg || new _.goa());
      const f = b.__gm;
      e.bindTo("zoom", f);
      e.bindTo("offset", f);
      e.bindTo("center", f, "projectionCenterQ");
      e.bindTo("projection", b);
      e.bindTo("projectionTopLeft", f);
      e = c.Ig = c.Ig || new bza(e);
      e.bindTo("zoom", f);
      e.bindTo("offset", f);
      e.bindTo("projection", b);
      e.bindTo("projectionTopLeft", f);
      a.bindTo("projection", e, "outProjection");
      a.bindTo("panes", f);
      e = () => _.Nq(d.Dg);
      c.Dg = [
        _.vn(a, "panes_changed", e),
        _.vn(f, "zoom_changed", e),
        _.vn(f, "offset_changed", e),
        _.vn(b, "projection_changed", e),
        _.vn(f, "projectioncenterq_changed", e),
      ];
      _.Nq(d.Dg);
      b instanceof _.co
        ? (_.vo(b, "Ox"), _.N(b, 148440))
        : b instanceof _.ap && (_.vo(b, "Oxs"), _.N(b, 181451));
    },
    dza = function (a) {
      const b = BI(a);
      var c = b.Gg;
      c && c.unbindAll();
      (c = b.Ig) && c.unbindAll();
      a.unbindAll();
      a.set("panes", null);
      a.set("projection", null);
      b.Dg &&
        b.Dg.forEach((d) => {
          _.xn(d);
        });
      b.Dg = null;
      b.Eg && (_.Oq(b.Eg.Dg), (b.Eg = null));
    },
    iza = function (a) {
      if (a) {
        var b = a.getMap();
        if (eza(a) !== b && b && b instanceof _.co) {
          const c = b.__gm;
          c.overlayLayer
            ? (a.__gmop = new fza(b, a, c.overlayLayer))
            : c.Eg.then(({ ah: d }) => {
                const e = new gza(b, d);
                d.Qi(e);
                c.overlayLayer = e;
                hza(a);
                iza(a);
              });
        }
      }
    },
    hza = function (a) {
      if (a) {
        var b = a.__gmop;
        b &&
          ((a.__gmop = null),
          b.overlay.unbindAll(),
          b.overlay.set("panes", null),
          b.overlay.set("projection", null),
          b.overlayLayer.uo(b),
          b.Dg &&
            ((b.Dg = !1),
            b.overlay.onRemove ? b.overlay.onRemove() : b.overlay.remove()));
      }
    },
    eza = function (a) {
      return (a = a.__gmop) ? a.map : null;
    },
    jza = function (a, b) {
      a.overlay.get("projection") !== b &&
        (a.overlay.bindTo("panes", a.map.__gm), a.overlay.set("projection", b));
    },
    bza = class extends _.On {
      constructor(a) {
        super();
        this.projection = a;
      }
      changed(a) {
        a !== "outProjection" &&
          ((a = !!(
            this.get("offset") &&
            this.get("projectionTopLeft") &&
            this.get("projection") &&
            _.mm(this.get("zoom"))
          )),
          a === !this.get("outProjection") &&
            this.set("outProjection", a ? this.projection : null));
      }
    };
  _.Ka(aza, _.On);
  var fza = class {
      constructor(a, b, c) {
        this.map = a;
        this.overlay = b;
        this.overlayLayer = c;
        this.Dg = !1;
        _.vo(this.map, "Ox");
        _.N(this.map, 148440);
        c.Mn(this);
      }
      draw() {
        this.Dg || ((this.Dg = !0), this.overlay.onAdd && this.overlay.onAdd());
        this.overlay.draw && this.overlay.draw();
      }
    },
    gza = class {
      constructor(a, b) {
        this.map = a;
        this.ah = b;
        this.Dg = null;
        this.Eg = [];
      }
      dispose() {}
      zh(a, b, c, d, e, f, g, h) {
        const k = (this.Dg = this.Dg || new _.fC(this.map, this.ah, () => {}));
        k.zh(a, b, c, d, e, f, g, h);
        for (const m of this.Eg) jza(m, k), m.draw();
      }
      Mn(a) {
        this.Eg.push(a);
        this.Dg && jza(a, this.Dg);
        this.ah.refresh();
      }
      uo(a) {
        _.Tb(this.Eg, a);
      }
    };
  _.Il("overlay", {
    UD: function (a) {
      if (a) {
        dza(a);
        delete BI(a).Hg;
        hza(a);
        var b = a.getMap();
        b &&
          (b instanceof _.co
            ? iza(a)
            : a &&
              ((b = a.getMap()),
              (BI(a).Hg || null) !== b && (b && cza(a, b), (BI(a).Hg = b))));
      }
    },
    preventMapHitsFrom: (a) => {
      _.Jy(a, {
        dm: ({ event: b }) => {
          _.Ax(b.Dg);
        },
        Ik: (b) => {
          _.uy(b);
        },
        Vq: (b) => {
          _.vy(b);
        },
        Hl: (b) => {
          _.vy(b);
        },
        Wk: (b) => {
          _.wy(b);
        },
      }).nr(!0);
    },
    preventMapHitsAndGesturesFrom: (a) => {
      a.addEventListener("click", _.tn);
      a.addEventListener("contextmenu", _.tn);
      a.addEventListener("dblclick", _.tn);
      a.addEventListener("mousedown", _.tn);
      a.addEventListener("mousemove", _.tn);
      a.addEventListener("MSPointerDown", _.tn);
      a.addEventListener("pointerdown", _.tn);
      a.addEventListener("touchstart", _.tn);
      a.addEventListener("wheel", _.tn);
    },
  });
});
