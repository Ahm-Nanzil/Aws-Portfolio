google.maps.__gjsload__("search", function (_) {
  var Cva = function (a) {
      const b = [];
      a.data.forEach((c) => {
        b.push(...Bva(c));
      });
      return b;
    },
    Bva = function (a) {
      let b = _.ep,
        c = -1;
      a.tiles.forEach((e) => {
        e.zoom > c && ((b = e.ui), (c = e.zoom));
      });
      if (c === -1) return [];
      const d = [];
      a.uv().forEach((e) => {
        e.a && e.a.length >= 2 && d.push(new Dva(e, b, c));
      });
      return d;
    },
    Eva = class extends _.On {};
  var Fva = { ["1"]: {} },
    Dva = class {
      constructor(a, b, c) {
        this.Jn = b;
        this.zoom = c;
        this.bounds = this.anchor = null;
        this.Dg = Fva;
        this.source = a;
        this.featureId = this.source.id || "0";
        this.infoWindowOffset =
          (this.source.io || []).length === 2
            ? new google.maps.Point(this.source.io[0], this.source.io[1])
            : null;
      }
      getAnchor() {
        if (!this.anchor) {
          const a = 1 << this.zoom;
          this.anchor = _.vs(
            new _.zr(
              (this.Jn.x * 256 + this.source.a[0]) / a,
              (this.Jn.y * 256 + this.source.a[1]) / a
            )
          ).toJSON();
        }
        return this.anchor;
      }
      getCompleteBounds() {
        return this.getBounds().reduce((a, b) => {
          a.extendByBounds(b);
          return a;
        }, _.sp(0, 0, 0, 0));
      }
      getBounds() {
        if (this.bounds === null) {
          this.bounds = [];
          const a = this.source.bb || [];
          if (a.length % 4 === 0)
            for (let b = 0; b < a.length; b += 4) {
              const c = this.bounds[this.bounds.length - 1],
                d = _.sp(a[b], a[b + 1], a[b + 2], a[b + 3]);
              (c && c.equals(d)) || this.bounds.push(d);
            }
        }
        return [...this.bounds];
      }
      getExtendedContent(a) {
        if (this.Dg === Fva)
          try {
            this.Dg = this.source.c ? JSON.parse(this.source.c) : {};
          } catch (b) {
            this.Dg = {};
          }
        return this.Dg[a] ?? {};
      }
      getFeatureName() {
        return this.getExtendedContent("1")?.title ?? null;
      }
      isTransitStation() {
        return this.getExtendedContent("1")?.is_transit_station ?? !1;
      }
    };
  var Gva = new WeakSet(),
    RH = class extends Eva {
      constructor(a) {
        super();
        this.setValues(a);
        this.setOptions = (b) => {
          this.setValues(b);
        };
        _.Hl("search_impl");
      }
      changed() {
        const a = this;
        var b = this.get("map");
        let c = null;
        b &&
          ((c = b.__gm),
          (b = Number(c.get("blockingLayerCount")) || 0),
          c.set("blockingLayerCount", b + 1),
          c.set(
            "disableLabelingHysteresis",
            this.get("disableLabelingHysteresis")
          ),
          c.set("tilePrefetchEnabled", this.get("tilePrefetchEnabled")));
        _.Hl("search_impl").then((d) => {
          d.Dg(a);
          c &&
            ((d = Number(c.get("blockingLayerCount")) || 0),
            c.set("blockingLayerCount", d - 1));
        });
      }
      static enableFeatureMapEventsRasterOnly(a) {
        if (_.br[15]) {
          var b = a.__gm.Yg;
          if (!Gva.has(a)) {
            Gva.add(a);
            var c = [],
              d = (f, g) => {
                f = Bva(f);
                f.length && _.Kn(a, g, f);
              },
              e = () => {
                for (; c.length > 0; ) c.pop().remove();
                b.forEach((f) => {
                  if ((f = f.data))
                    c.push(
                      _.vn(f, "insert", (g) => {
                        d(g, "addfeatures");
                      })
                    ),
                      c.push(
                        _.vn(f, "remove", (g) => {
                          d(g, "removefeatures");
                        })
                      );
                });
              };
            b.addListener("insert_at", e);
            b.addListener("remove_at", e);
            b.addListener("set_at", e);
            e();
          }
          (() => {
            const f = [];
            b.forEach((g) => {
              f.push(...Cva(g));
            });
            f.length && _.Kn(a, "addfeatures", f);
          })();
        }
      }
    };
  RH.enableFeatureMapEventsRasterOnly = RH.enableFeatureMapEventsRasterOnly;
  _.qo(RH.prototype, { map: _.Jt });
  _.pa.google.maps.search = { GoogleLayer: RH };
  _.Il("search", {});
});
