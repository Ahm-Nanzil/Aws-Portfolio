google.maps.__gjsload__("search_impl", function (_) {
  var Swb = function (a, b) {
      return _.Cg(a, 1, b);
    },
    Twb = function (a, b) {
      return _.Cg(a, 2, b);
    },
    Vwb = function (a) {
      if (_.br[15]) {
        var b = a.Gg;
        const c = (a.Gg = a.getMap());
        b &&
          a.Dg &&
          (a.Fg
            ? ((b = b.__gm.Dk), b.set(b.get().vo(a.Dg)))
            : a.Dg &&
              _.IWa(a.Dg, b) &&
              ((a.Eg || []).forEach(_.xn), (a.Eg = null)));
        if (c) {
          b = new _.Az();
          const d = a.get("layerId").split("|");
          b.layerId = d[0];
          for (let e = 1; e < d.length; ++e) {
            const [f, ...g] = d[e].split(":");
            b.parameters[f] = g.join(":");
          }
          a.get("spotlightDescription") &&
            (b.spotlightDescription = _.qh(
              _.Oy,
              _.FI(a.get("spotlightDescription"))
            ));
          a.get("paintExperimentIds") &&
            (b.paintExperimentIds = a.get("paintExperimentIds").slice(0));
          a.get("styler") && (b.styler = _.qh(_.Ky, _.FI(a.get("styler"))));
          a.get("roadmapStyler") &&
            (b.roadmapStyler = _.qh(_.Ky, _.FI(a.get("roadmapStyler"))));
          a.get("travelMapRequest") &&
            (b.travelMapRequest = _.qh(_.DB, _.FI(a.get("travelMapRequest"))));
          a.get("mapsApiLayer") &&
            (b.mapsApiLayer = _.qh(_.Py, _.FI(a.get("mapsApiLayer"))));
          a.get("mapFeatures") && (b.mapFeatures = a.get("mapFeatures"));
          a.get("clickableCities") &&
            (b.clickableCities = a.get("clickableCities"));
          a.get("searchPipeMetadata") &&
            (b.searchPipeMetadata = _.qh(
              _.jB,
              _.FI(a.get("searchPipeMetadata"))
            ));
          a.get("gmmContextPipeMetadata") &&
            (b.gmmContextPipeMetadata = _.qh(
              _.nB,
              _.FI(a.get("gmmContextPipeMetadata"))
            ));
          a.get("overlayLayer") &&
            (b.overlayLayer = _.qh(_.Qy, _.FI(a.get("overlayLayer"))));
          a.get("caseExperimentIds") &&
            (b.caseExperimentIds = a.get("caseExperimentIds").slice(0));
          a.get("boostMapExperimentIds") &&
            (b.boostMapExperimentIds = a.get("boostMapExperimentIds").slice(0));
          a.get("airQualityPipeMetadata") &&
            (b.airQualityPipeMetadata = _.qh(
              _.CB,
              _.FI(a.get("airQualityPipeMetadata"))
            ));
          a.get("directionsPipeParameters") &&
            (b.directionsPipeParameters = _.qh(
              _.BB,
              _.FI(a.get("directionsPipeParameters"))
            ));
          a.get("clientSignalPipeMetadata") &&
            (b.clientSignalPipeMetadata = _.qh(
              _.TA,
              _.FI(a.get("clientSignalPipeMetadata"))
            ));
          b.darkLaunch = !!a.get("darkLaunch");
          a.Dg = b;
          a.Fg = a.get("renderOnBaseMap");
          a.Fg ? ((a = c.__gm.Dk), a.set(_.Jw(a.get(), b))) : Uwb(a, c, b);
          _.vo(c, "Lg");
          _.N(c, 148282);
        }
      }
    },
    Uwb = function (a, b, c) {
      var d = new Wwb();
      d = _.EL(d);
      c.Fg = d.load.bind(d);
      c.clickable = a.get("clickable") !== !1;
      _.gWa(c, _.PS(b));
      b = [];
      b.push(_.vn(c, "click", Xwb.bind(null, a)));
      for (const e of ["mouseover", "mouseout", "mousemove"])
        b.push(_.vn(c, e, Ywb.bind(null, a, e)));
      b.push(
        _.vn(a, "clickable_changed", () => {
          a.Dg.clickable = a.get("clickable") !== !1;
        })
      );
      a.Eg = b;
    },
    Xwb = function (a, b, c, d, e) {
      let f = null;
      if (e && ((f = { status: e.getStatus() }), e.getStatus() === 0)) {
        f.location = _.rf(e, _.NA, 2)
          ? new _.dn(_.Dx(_.D(e, _.NA, 2)), _.Fx(_.D(e, _.NA, 2)))
          : null;
        const g = {};
        f.fields = g;
        const h = _.vf(e, _.VS, 3);
        for (let k = 0; k < h; ++k) {
          const m = _.Ov(e, 3, _.VS, k);
          g[m.getKey()] = m.getValue();
        }
      }
      _.Kn(a, "click", b, c, d, f);
    },
    Ywb = function (a, b, c, d, e, f, g) {
      let h = null;
      f && (h = { title: f[1].title, snippet: f[1].snippet });
      _.Kn(a, b, c, d, e, h, g);
    },
    Zwb = class extends _.L {
      constructor(a) {
        super(a);
      }
      nk() {
        return _.E(this, 2);
      }
      ri(a) {
        return _.Cg(this, 3, a);
      }
      Yj() {
        return _.Iv(this, 3);
      }
    },
    $wb = _.ei(Zwb, [0, _.T, -2, _.V, _.rXa]),
    axb = class extends _.L {
      constructor(a) {
        super(a);
      }
      getStatus() {
        return _.kg(this, 1, -1);
      }
      getLocation() {
        return _.Wf(this, _.NA, 2);
      }
    },
    bxb = class {},
    Wwb = class {
      constructor() {
        var a = _.Js,
          b = _.Is;
        this.Dg = _.dl;
        this.fetch = _.cA.bind(
          bxb,
          a,
          _.bC + "/maps/api/js/LayersService.GetFeature",
          b
        );
      }
      load(a, b) {
        function c(e) {
          b(new axb(e && e));
        }
        const d = Twb(Swb(new Zwb(), a.layerId.split("|")[0]), a.featureId).ri(
          this.Dg.Eg().Eg()
        );
        for (const e in a.parameters)
          _.NVa(_.wf(d, 4, _.VS), e).setValue(a.parameters[e]);
        a = _.Zi(d, $wb());
        this.fetch(a, c, c);
        return a;
      }
      cancel() {
        throw Error("Not implemented");
      }
    };
  _.Il(
    "search_impl",
    new (class {
      constructor() {
        this.Dg = Vwb;
      }
    })()
  );
});
