google.maps.__gjsload__("geometry", function (_) {
  var ioa = function (a, b) {
      return Math.abs(_.km(b - a, -180, 180));
    },
    joa = function (a, b, c, d, e) {
      if (!d) {
        c = ioa(a.lng(), c) / ioa(a.lng(), b.lng());
        if (!e)
          return (
            (e = Math.sin(_.ll(a.lat()))),
            (e = Math.log((1 + e) / (1 - e)) / 2),
            (b = Math.sin(_.ll(b.lat()))),
            _.ml(
              2 *
                Math.atan(
                  Math.exp(e + c * (Math.log((1 + b) / (1 - b)) / 2 - e))
                ) -
                Math.PI / 2
            )
          );
        a = e.fromLatLngToPoint(a);
        b = e.fromLatLngToPoint(b);
        return e
          .fromPointToLatLng(
            new _.Do(a.x + c * (b.x - a.x), a.y + c * (b.y - a.y))
          )
          .lat();
      }
      e = _.ll(a.lat());
      a = _.ll(a.lng());
      d = _.ll(b.lat());
      b = _.ll(b.lng());
      c = _.ll(c);
      return _.km(
        _.ml(
          Math.atan2(
            Math.sin(e) * Math.cos(d) * Math.sin(c - b) -
              Math.sin(d) * Math.cos(e) * Math.sin(c - a),
            Math.cos(e) * Math.cos(d) * Math.sin(a - b)
          )
        ),
        -90,
        90
      );
    },
    koa = function (a, b) {
      a = new _.dn(a, !1);
      b = new _.dn(b, !1);
      return a.equals(b);
    },
    loa = function (a, b, c) {
      a = _.kn(a);
      c = c || 1e-9;
      const d = _.km(a.lng(), -180, 180),
        e = b instanceof _.Wu,
        f = !!b.get("geodesic"),
        g = b.get("latLngs");
      b = b.get("map");
      b = !f && b ? b.getProjection() : null;
      for (let r = 0, t = g.getLength(); r < t; ++r) {
        const v = g.getAt(r),
          w = v.getLength(),
          y = e ? w : w - 1;
        for (let C = 0; C < y; ++C) {
          var h = v.getAt(C);
          const F = v.getAt((C + 1) % w);
          if (koa(h, a) || koa(F, a)) return !0;
          var k = _.km(h.lng(), -180, 180),
            m = _.km(F.lng(), -180, 180);
          const J = Math.max(k, m),
            H = Math.min(k, m);
          if (
            (k =
              Math.abs(_.km(k - m, -180, 180)) <= 1e-9 &&
              (Math.abs(_.km(k - d, -180, 180)) <= c ||
                Math.abs(_.km(m - d, -180, 180)) <= c))
          ) {
            k = a.lat();
            m = Math.min(h.lat(), F.lat()) - c;
            var p = Math.max(h.lat(), F.lat()) + c;
            k = k >= m && k <= p;
          }
          if (k) return !0;
          if (J - H > 180 ? d + c >= J || d - c <= H : d + c >= H && d - c <= J)
            if (((h = joa(h, F, d, f, b)), Math.abs(h - a.lat()) < c))
              return !0;
        }
      }
      return !1;
    },
    moa = function (a, b) {
      const c = _.fn(a);
      a = _.gn(a);
      const d = _.fn(b);
      b = _.gn(b);
      return (
        2 *
        Math.asin(
          Math.sqrt(
            Math.pow(Math.sin((c - d) / 2), 2) +
              Math.cos(c) * Math.cos(d) * Math.pow(Math.sin((a - b) / 2), 2)
          )
        )
      );
    },
    noa = function (a, b, c) {
      a = _.kn(a);
      b = _.kn(b);
      c = c || 6378137;
      return moa(a, b) * c;
    },
    qoa = function (a, b) {
      b = b || 6378137;
      a instanceof _.xp && (a = a.getArray());
      a = (0, _.Ht)(a);
      if (a.length === 0) return 0;
      const c = Array(4),
        d = Array(3),
        e = [1, 0, 0, 0],
        f = Array(3);
      ooa(a[a.length - 1], f);
      for (let v = 0; v < a.length; ++v)
        ooa(a[v], d), rD(f, d, c), poa(c, e, e), ([f[0], f[1], f[2]] = d);
      const [g, h, k] = f,
        [m, p, r, t] = e;
      return 2 * Math.atan2(g * p + h * r + k * t, m) * (b * b);
    },
    roa = function (a, b) {
      if (isFinite(a)) {
        var c = a % 360;
        a = Math.round(c / 90);
        c -= a * 90;
        if (c === 30 || c === -30) {
          c = Math.sign(c) * 0.5;
          var d = Math.sqrt(0.75);
        } else
          c === 45 || c === -45
            ? ((c = Math.sign(c) * Math.SQRT1_2), (d = Math.SQRT1_2))
            : ((d = (c / 180) * Math.PI), (c = Math.sin(d)), (d = Math.cos(d)));
        switch (a & 3) {
          case 0:
            b[0] = c;
            b[1] = d;
            break;
          case 1:
            b[0] = d;
            b[1] = -c;
            break;
          case 2:
            b[0] = -c;
            b[1] = -d;
            break;
          default:
            (b[0] = -d), (b[1] = c);
        }
      } else (b[0] = NaN), (b[1] = NaN);
    },
    ooa = function (a, b) {
      const c = Array(2);
      roa(a.lat(), c);
      const [d, e] = c;
      roa(a.lng(), c);
      const [f, g] = c;
      b[0] = e * g;
      b[1] = e * f;
      b[2] = d;
    },
    poa = function (a, b, c) {
      const d = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
        e = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
        f = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0];
      c[0] = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3];
      c[1] = d;
      c[2] = e;
      c[3] = f;
    },
    rD = function (a, b, c) {
      var d = a[0] - b[0],
        e = a[1] - b[1],
        f = a[2] - b[2];
      const g = a[0] + b[0],
        h = a[1] + b[1],
        k = a[2] + b[2];
      var m = g * g + h * h + k * k,
        p = e * k - f * h;
      f = f * g - d * k;
      d = d * h - e * g;
      e = m * m + p * p + f * f + d * d;
      if (e !== 0)
        (b = Math.sqrt(e)),
          (c[0] = m / b),
          (c[1] = p / b),
          (c[2] = f / b),
          (c[3] = d / b);
      else {
        a: for (m = [a[0] - b[0], a[1] - b[1], a[2] - b[2]], p = 0; p < 3; ++p)
          if (m[p] !== 0) {
            if (m[p] < 0) {
              m = [-m[0], -m[1], -m[2]];
              break a;
            }
            break;
          }
        p = 0;
        for (f = 1; f < m.length; ++f)
          Math.abs(m[f]) < Math.abs(m[p]) && (p = f);
        f = [0, 0, 0];
        f[p] = 1;
        m = [
          m[1] * f[2] - m[2] * f[1],
          m[2] * f[0] - m[0] * f[2],
          m[0] * f[1] - m[1] * f[0],
        ];
        p = Math.hypot(...m);
        m = [m[0] / p, m[1] / p, m[2] / p];
        p = Array(4);
        rD(a, m, p);
        a = Array(4);
        rD(m, b, a);
        poa(a, p, c);
      }
    },
    sD = class {};
  sD.isLocationOnEdge = loa;
  sD.containsLocation = function (a, b) {
    a = _.kn(a);
    const c = _.km(a.lng(), -180, 180),
      d = !!b.get("geodesic"),
      e = b.get("latLngs");
    var f = b.get("map");
    f = !d && f ? f.getProjection() : null;
    let g = !1;
    for (let k = 0, m = e.getLength(); k < m; ++k) {
      const p = e.getAt(k);
      for (let r = 0, t = p.getLength(); r < t; ++r) {
        const v = p.getAt(r),
          w = p.getAt((r + 1) % t);
        var h = _.km(v.lng(), -180, 180);
        const y = _.km(w.lng(), -180, 180),
          C = Math.max(h, y);
        h = Math.min(h, y);
        (C - h > 180 ? c >= C || c < h : c < C && c >= h) &&
          joa(v, w, c, d, f) < a.lat() &&
          (g = !g);
      }
    }
    return g || loa(a, b);
  };
  var tD = class {};
  tD.computeSignedArea = qoa;
  tD.computeArea = function (a, b) {
    if (
      !(
        a instanceof _.xp ||
        Array.isArray(a) ||
        a instanceof _.ko ||
        a instanceof _.Ep
      )
    )
      try {
        a = _.jo(a);
      } catch (c) {
        try {
          a = new _.Ep((0, _.Hda)(a));
        } catch (d) {
          throw _.Hm(
            "Invalid path passed to computeArea(): " + JSON.stringify(a)
          );
        }
      }
    b = b || 6378137;
    if (a instanceof _.Ep) {
      if (a.getRadius() === void 0)
        throw _.Hm(
          "Invalid path passed to computeArea(): Circle is missing radius."
        );
      if (a.getRadius() < 0)
        throw _.Hm(
          "Invalid path passed to computeArea(): Circle must have non-negative radius."
        );
      if (b < 0)
        throw _.Hm(
          "Invalid radiusOfSphere passed to computeArea(): radiusOfSphere must be non-negative."
        );
      if (a.getRadius() > Math.PI * b)
        throw _.Hm(
          "Invalid path passed to computeArea(): Circle must not cover more than 100% of the sphere."
        );
      return 2 * Math.PI * b ** 2 * (1 - Math.cos(a.getRadius() / b));
    }
    if (a instanceof _.ko) {
      if (b < 0)
        throw _.Hm(
          "Invalid radiusOfSphere passed to computeArea(): radiusOfSphere must be non-negative."
        );
      if (a.si.lo > a.si.hi)
        throw _.Hm(
          "Invalid path passed to computeArea(): the southern LatLng of a LatLngBounds cannot be more north than the northern LatLng."
        );
      let c =
        2 * Math.PI * b ** 2 * (1 - Math.cos(((a.si.lo - 90) * Math.PI) / 180));
      c -=
        2 * Math.PI * b ** 2 * (1 - Math.cos(((a.si.hi - 90) * Math.PI) / 180));
      return (c * Math.abs(a.Lh.hi - a.Lh.lo)) / 360;
    }
    return Math.abs(qoa(a, b));
  };
  tD.computeLength = function (a, b) {
    b = b || 6378137;
    let c = 0;
    a instanceof _.xp && (a = a.getArray());
    for (let d = 0, e = a.length - 1; d < e; ++d) c += noa(a[d], a[d + 1], b);
    return c;
  };
  tD.computeDistanceBetween = noa;
  tD.interpolate = function (a, b, c) {
    a = _.kn(a);
    b = _.kn(b);
    const d = _.fn(a);
    var e = _.gn(a);
    const f = _.fn(b),
      g = _.gn(b),
      h = Math.cos(d),
      k = Math.cos(f);
    b = moa(a, b);
    const m = Math.sin(b);
    if (m < 1e-6) return new _.dn(a.lat(), a.lng());
    a = Math.sin((1 - c) * b) / m;
    c = Math.sin(c * b) / m;
    b = a * h * Math.cos(e) + c * k * Math.cos(g);
    e = a * h * Math.sin(e) + c * k * Math.sin(g);
    return new _.dn(
      _.ml(
        Math.atan2(a * Math.sin(d) + c * Math.sin(f), Math.sqrt(b * b + e * e))
      ),
      _.ml(Math.atan2(e, b))
    );
  };
  tD.computeOffsetOrigin = function (a, b, c, d) {
    a = _.kn(a);
    c = _.ll(c);
    b /= d || 6378137;
    d = Math.cos(b);
    const e = Math.sin(b) * Math.cos(c);
    b = Math.sin(b) * Math.sin(c);
    c = Math.sin(_.fn(a));
    const f = e * e * d * d + d * d * d * d - d * d * c * c;
    if (f < 0) return null;
    var g = e * c + Math.sqrt(f);
    g /= d * d + e * e;
    const h = (c - e * g) / d;
    g = Math.atan2(h, g);
    if (g < -Math.PI / 2 || g > Math.PI / 2)
      (g = e * c - Math.sqrt(f)), (g = Math.atan2(h, g / (d * d + e * e)));
    if (g < -Math.PI / 2 || g > Math.PI / 2) return null;
    a = _.gn(a) - Math.atan2(b, d * Math.cos(g) - e * Math.sin(g));
    return new _.dn(_.ml(g), _.ml(a));
  };
  tD.computeOffset = function (a, b, c, d) {
    a = _.kn(a);
    b /= d || 6378137;
    c = _.ll(c);
    var e = _.fn(a);
    a = _.gn(a);
    d = Math.cos(b);
    b = Math.sin(b);
    const f = Math.sin(e);
    e = Math.cos(e);
    const g = d * f + b * e * Math.cos(c);
    return new _.dn(
      _.ml(Math.asin(g)),
      _.ml(a + Math.atan2(b * e * Math.sin(c), d - f * g))
    );
  };
  tD.computeHeading = function (a, b) {
    a = _.kn(a);
    b = _.kn(b);
    const c = _.fn(a),
      d = _.gn(a);
    a = _.fn(b);
    b = _.gn(b) - d;
    return _.km(
      _.ml(
        Math.atan2(
          Math.sin(b) * Math.cos(a),
          Math.cos(c) * Math.sin(a) - Math.sin(c) * Math.cos(a) * Math.cos(b)
        )
      ),
      -180,
      180
    );
  };
  var soa = { encoding: _.mv, spherical: tD, poly: sD };
  _.pa.google.maps.geometry = soa;
  _.Il("geometry", soa);
});
